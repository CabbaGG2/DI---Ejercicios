import sys


from PyQt6.QtWidgets import (QApplication, QMainWindow, QGridLayout, QVBoxLayout, QHBoxLayout, QWidget,
                             QLabel, QListWidget, QPushButton, QComboBox, QLineEdit,
                             QRadioButton, QGroupBox, QTableView, QAbstractItemView, QTextEdit)



class FiestraPrincipal (QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Examen 16-11-2025 grupo B")

        cajaV = QVBoxLayout()

        gpbCliente = QGroupBox("Cliente")
       
        self.provincias = [["","A Coruña","Lugo","Ourense","Pontevedra"]]

        malla = QGridLayout()

        self.lblNumeroCliente = QLabel("Número Cliente")
        self.lblNomeCliente = QLabel("Nome")
        self.lblApelidosCliente = QLabel("Apelidos")
        self.lblDirección = QLabel("Dirección")
        self.lblCidade = QLabel("Cidade")
        self.lblProvinciaEstado = QLabel("Provincia")

        self.txtNumeroCliente = QLineEdit()
        self.txtNomeCliente = QLineEdit()
        self.txtApelidosCliente = QLineEdit()
        self.txtDireccion = QLineEdit()
        self.txtCidade = QLineEdit()
        self.cmbProvincia = QComboBox()

        malla.addWidget(self.lblNumeroCliente)
        malla.addWidget(self.txtNumeroCliente,0,1,1,1)
        malla.addWidget(self.lblNomeCliente,0,2,1,1)
        malla.addWidget(self.txtNomeCliente,0,3,1,1)
        malla.addWidget(self.lblApelidosCliente,1,0,1,1)
        malla.addWidget(self.txtApelidosCliente,1,1,1,3)
        malla.addWidget(self.lblDirección,2,0,1,1)
        malla.addWidget(self.txtDireccion,2,1,1,3)
        malla.addWidget(self.lblCidade,3,0,1,1)
        malla.addWidget(self.txtCidade,3,1,1,1)
        malla.addWidget(self.lblProvinciaEstado,3,2,1,1)
        malla.addWidget(self.cmbProvincia,3,3,1,1)

        self.cmbProvincia.addItems(self.provincias[0])
        self.cmbProvincia.currentTextChanged.connect(self.btn_clicker_engadir)

        gpbCliente.setLayout(malla)
        cajaV.addWidget(gpbCliente)


        malla2 = QGridLayout()

        self.txeClientes = QTextEdit()

        self.btnEngadir = QPushButton("Engadir")
        self.btnEngadir.clicked.connect(self.btn_clicker_engadir)
        self.btnEditar = QPushButton("Editar")
        self.btnBorrar = QPushButton("Borrar")

        self.btnAceptar = QPushButton("Aceptar")
        self.btnCancelar = QPushButton("Cancelar")

        malla2.addWidget(self.txeClientes,0,0,5,8)
        malla2.addWidget(self.btnEngadir,0,8,1,1)
        malla2.addWidget(self.btnEditar,1,8,1,1)
        malla2.addWidget(self.btnBorrar,2,8,1,1)
        malla2.addWidget(self.btnCancelar,5,7,1,1)
        malla2.addWidget(self.btnAceptar,5,8,1,1)

        cajaV.addLayout(malla2)

        container = QWidget()
        container.setLayout(cajaV)

        self.setCentralWidget(container)
        self.show()

    def btn_clicker_engadir(self, indice):
        numeroCliente = self.txtNumeroCliente.text().strip()
        nome = self.txtNomeCliente.text().strip()
        apellidos = self.txtApelidosCliente.text().strip()
        direccion = self.txtDireccion.text().strip()
        ciudad = self.txtCidade.text().strip()
        provincia = self.cmbProvincia.currentText()
        dato = []

        if not nome:
            self.lblNomeCliente.setStyleSheet("background-color: red")
            return
        if not numeroCliente:
            self.lblNumeroCliente.setStyleSheet("background-color: red")
            return
        if not apellidos:
            self.lblApelidosCliente.setStyleSheet("background-color: red")
            return
        if not direccion:
            self.lblDirección.setStyleSheet("background-color: red")
            return
        if not ciudad:
            self.lblCidade.setStyleSheet("background-color: red")
            return
        if provincia is "":
            self.lblProvinciaEstado.setStyleSheet("background-color: red")
            return

        dato.append("Numero de cliente: " + self.txtNumeroCliente.text() + " Nombre: " + self.txtNomeCliente.text()+ " Apellidos: " + self.txtApelidosCliente.text() + " Dirección: " + self.txtDireccion.text() + " Ciudad: " + self.txtCidade.text() + " Provincia: " + self.cmbProvincia.currentText())
        
        self.txeClientes.setPlainText(str(dato))


if __name__=="__main__":

    aplicacion = QApplication(sys.argv)
    fiestra = FiestraPrincipal()

    aplicacion.exec()